#1
int LARGER(int left_depth, int right_depth)
void maxDepth(BST *tree)  //這個function會印出題1所求

#4
void DFS(node* x, bool is_left, int &max_path, int curr_path)
void longestZigZag(BST* tree)  //這個function會印出題4所求

#6
int get_bigger(int a, int b)
void second_min(BT* tree)  //這個function會印出題6所求
